# coding=utf-8
import utils; from utils import rf,wf
import re
import collections

class Transition:
	"""Models a transition in a dfa.



	"""
	
	def __init__(self, sourceState, destState, label):
		"""Initialize Transition object.

		Args:

			sourceState (str): the state from which this transition begins, e.g. 'q2'

			destState (str): the state in which this transition ends, e.g. 'q5'

			label (str): the scanned symbols for which this transition
				is followed, e.g. 'G'

		  

		"""
		self.sourceState = sourceState
		self.destState = destState
		self.label = label
	   

	def __str__(self):
		return 'sourceState: %s destState: %s label: %s' %\
			(self.sourceState, self.destState, self.label)

	def __repr__(self):
		return self.__str__()
	
	# Static method to unify the labels of compatible transitions
	@staticmethod
	def unify(tList):
		"""Unify the transitions in a list of compatible transitions.

		Transitions are compatible if they have the same source state,
		destination state. That is, they
		may differ in their label but nothing else. Sometimes it is
		convenient to unify compatible transitions by transforming
		them into a single transition with a new label that
		incorporates all of the input transitions. This method returns
		a single transition that unifies a given list of transitions,
		which must themselves all be compatible.

		Args:

			tList (list of Transition objects): the list of compatible
				transitions that will be unified.

		Returns:

			Transition: a single unified transition representing all
				transitions in tList.

		"""
		assert len(tList)>0
		first = tList[0]
		unifiedTrans = Transition(first.sourceState, first.destState, None)
		for t in tList:
			assert unifiedTrans.isCompatible(t)
		labels = [t.label for t in tList]
		unifiedTrans.label = ''.join(labels)
		return unifiedTrans

	def isCompatible(self, other):
		"""Determine whether this transition is compatible with the other transition.

		Transitions are compatible if they have the same source state,
		destination state, write symbol, and direction. That is, they
		may differ in their label but nothing else. This method
		returns True if this transition is compatible with the other
		transition, and False otherwise.

		Args:

			other (Transition): A Transition object to be compared
				with the calling Transition object.

		Returns:

			bool: True if this transition is compatible with the other
				transition, and False otherwise

		"""
		
		return self.sourceState == other.sourceState \
			and self.destState == other.destState 
		  

	def __eq__(self, other):
		if self is other: return True
		if other==None: return False
		if not isinstance(other, Transition): return False
		return self.sourceState == other.sourceState \
				and self.destState == other.destState \
				and self.label == other.label 

	def __ne__(self, other):
		return not self==other

	def __lt__ (self, other):
		return (self.sourceState, self.destState, self.label) \
			< \
			(other.sourceState, other.destState, other.label)

	def __gt__ (self, other):
		return other.__lt__(self)

	def getKeyForUnify(self):
		"""Returns a key that can be used for collecting compatible transitions.

		See isCompatible() for a description of transition
		compatibility.

		Returns:

			(src, dest, writeSym, dir): a 4-tuple of str, consisting
				of the four attributes that determine with the
				transitions are compatible with each other.

		"""
		return (self.sourceState, self.destState)

	@staticmethod
	def reassembleFromUnifyKey(key, label):
		"""Re-create a transition from its compatibility key and label.

		See isCompatible() for a description of transition
		compatibility. See getKeyForUnify() for a description of
		compatibility keys. This method takes the 4-tuple
		compatibility key and returns a new Transition object
		compatible with that key and the given label.

		Args:

			key (4-tuple of str: (src, dest, writeSym, dir)): A
			compatibility key.

			label (str): the label for the new transition

		Returns:

			Transition: New transition object with the given label and
				compatibility key.

		"""
		return Transition(key[0], key[1], label)



""" PRINCIPAL """

class afd:
	"""Un autómata finito determinista.

	"""
	
   
	# Un blanco se representa como guion bajo

	blank = '_'

	epsilon = '-'

	# Símbolos especiales 

	anySym = '~' # cualquier símbolo
	notSym = '!' # cualquier símbolo excepto el siguiente
	stateSeparator = '->'
	labelSeparator = ':'
	commentStart = '#'

	validSymbols = {c for c in
		r"""$'"%&()*+-./0123456789<>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}"""}
	
   
	
	def __init__(self, description = None, name = None, allowImplicitReject=False, verbose=True):
		"""Initialize TuringMachine object.

		Args:

			description (str): Una cadena de caractereres con la descripcion del AFD

			tapeStr (str): La palabra de entrada

			name (str): Un nombre 

			allowImplicitReject (bool):
		"""

		# Las transiciones son un diccionario con los estados como índice. Cada entrada contendrá 
	# la lista de transiciones que salen de ese estado 

		self.states = None
		self.final = None
		self.alphabet = None
		self.transitions = None

		self.error = "Err"

		# The name of the machine can be used for debugging and meaningful output.
		self.name = name
		self.allowImplicitReject = allowImplicitReject
		self.verbose = verbose

		
		if description:
			self.read(description)
		self.checkAllSymbolsValid()


	def splitTransition(self, line):
		"""Given a line in a Turing machine description, split into transition components.

		Args:

			line (str): a line in a Turing machine description

		Returns:

			4-tuple of str (label, actions, sourceState, destState):
				where label, sourceState, destState are attributes as
				described in the documentation for the Transition
				class, and actions is a string containing the write
				symbol, if any, and the direction.

		"""
		
		(source,rest) = line.split('->')
		(dest,label) = rest.split(':')
			  
	  
		return (source.strip(), dest.strip(), label.strip())

	def extractStates(self,line):

	
		self.states = line.split()

	def extractFinal(self,line):

	
		self.final = line.split()


	def extractTransition(self, line):
		"""Given a line in a Turing machine description, return a new Transition object described by that   line.

		Args:

			line (str): a line in a Turing machine description

		Returns:

			Transition: a new Transition object

		"""
		(source, dest, label) = \
				self.splitTransition(line)
	   
		return Transition(source, dest, label)





	@staticmethod
	def stripComments(lines):
		"""Strip comments from a Turing machine description.

		A comment is anything after a '#' chaacter on a given line.

		Args:

			lines (list of str): list of lines in the Turing machine
				description.

		Returns:

			list of str: The same list of Turing machine description
				lines with comments removed.

		"""

		return [x.split(afd.commentStart)[0] for x in lines]

	
	def read(self, afdString):
		"""Build the states and transitions of a Turing machine from an ASCII description.

		This method creates the self.transitions dictionary attribute,
		and populates it with the transitions in the given
		description. Nothing is returned. This method can also deal
		with building blocks, recursively reading descriptions of any
		building blocks encountered and adding them to the current
		machine.

		Args:

			tmString (str): Turing machine description.

		"""

		self.transitions = dict()
		# split on newlines
		afdLines = afdString.split('\n')
		# strip comments
		afdLines = afd.stripComments(afdLines)

		

		self.extractStates(afdLines[0])
		self.extractFinal(afdLines[1])
		self.alphabet = afdLines[2].strip()

		afdLines = [x.strip() for x in afdLines[3:]]
 
	 

		for line in afdLines:
			if len(line)>0:
				t = self.extractTransition(line)
				self.addTransition(t)


	def save(self,filename):
		descrip = self.write()
		wf(filename,descrip)

	def writeTransition(self, t):
		"""Convert a transition into Turing machine description format.

		Args:

			t (Transition): the Transition object to be converted to
				description format

		Returns:

			str: description format of the transition t

		"""

		components = [t.sourceState, afd.stateSeparator, t.destState,
					  afd.labelSeparator, ' ', t.label]
	   
	   
		return ''.join(components)
			
	def write(self):
		"""Convert the current Turing machine into description format.

		Returns:

			str: description format of the current machine, suitable
				for storing in a .df file.

		"""

		lines = []
		if self.transitions == None: 
			return '[No transitions]'
		line = ' '.join(self.states)
		lines.append(line)
		line = ' '.join(self.final)
		lines.append(line)
		lines.append(self.alphabet)
		for tList in self.transitions.values():
			for t in tList:
				line = self.writeTransition(t)
				lines.append(line)
		lines[3:].sort()
		return '\n'.join(lines)

   


	@staticmethod
	def labelMatchesSymbol(symbol, label):
		"""Return True if the given symbol is valid for a transition with the given label.

		Usually, this will return True if symbol is one of the
		characters in label, but this method also handles certain
		special cases, such as the special symbol that matches any
		character, and the use of '!' for "not".

		Args:

			symbol (str): a single character

			label (str): the label attribute of a Transition. See the
				Transition documentation.

		Returns:

			bool: True if the symbol is valid for a transition
				with the given label, and False otherwise.

		"""

		if afd.anySym == label:
			return True
		elif label[0] == afd.notSym:
			if symbol not in label[1:]: 
				return True
		elif symbol in label:
			return True
		else:
			return False
		

	# is t a valid transition?

	@staticmethod
	def isValidTransition(c,t):
		"""Return True if t is a valid transition for the current configuration.

		Args:

			t (Transition): a Transition object

		Returns:

			bool: True if the current scanned symbol matches the label
				of t, meaning that t is a transition that can be
				followed from the current configuration.

		"""

	
		
		return afd.labelMatchesSymbol(c, t.label)


	# get a list of the possible transitions from the given state
	def getTransitions(self, state):
		"""Return a list of the possible transitions from the given state.

		This ignores the scanned symbol. The returned transitions are
		all the transitions that could ever be followed from the
		given state.

		Args:

			state (str): a state in the Turing machine

		Returns:

			list of Transition objects: A list containing all
				transitions whose source state is the given state
				parameter. This could be the empty list.

		"""
		return self.transitions.get(state, [])


	def getValidTransitions(self,c,state):
		"""Return a list of all valid transitions from the current configuration.

		This is a list of all transitions from the current state whose
		label matches the current scanned symbol.

		Returns:

			list of Transition objects: A list containing all valid
				transitions from the current configuration. This could
				be the empty list.

		"""
		transitionList = self.getTransitions(state)
		ts = []
		for t in transitionList:
			if afd.isValidTransition(c,t):
				ts.append(t)
		return ts




	def printTransitions(self):
		"""Print the transitions of this machine"""
		for t in self.transitions.values():
			print(t)

	def addTransition(self, t):
		"""Add a transition to this machine.

		Args:

			t (Transition): the Transition object to be added
		"""
		if self.transitions == None:
			self.transitions = dict()
		transitionList = self.transitions.setdefault(t.sourceState, [])
		transitionList.append(t)

	def checkSymbolIsValid(self, t, c):
		"""Check if a given symbol is permitted in Turing machines.

		Nothing is returned, but a WcbcException is raised if the
		symbol is invalid.

		Args:

			t (Transition): the Transition in which c is used.

			c (str): a single character which is the symbol to be
				checked

		"""
		if c not in afd.validSymbols:
			message = '''***Error***: The symbol {0} (ASCII value {1}) is not permitted in Turing machine alphabets. The full transition containing this error is:\n{2}'''.format(c, ord(c), t)
			raise utils.WcbcException(message)
			

	def checkAllSymbolsValid(self):
		"""Check that all symbols used in this machine are permitted.

		Nothing is returned, but a WcbcException is raised if a
		symbol is invalid.
		"""
		if self.transitions:
			for tList in self.transitions.values():
				for t in tList:
					label = t.label
					if label==afd.anySym:
						continue
					elif label[0]==afd.notSym:
						label = label[1:]
					for c in label:
						self.checkSymbolIsValid(t, c)


   
	def sortLabelChars(self, s):
		"""Sort the characters in the transition label.

		We are given a line of a Turing machine description, and an
		equivalent line is returned. The only difference is that if
		there are multiple characters in the transition label, these
		characters are sorted into ascending order. This brings the
		description into a standard form that can be compared against
		other machines more easily.

		Args:

			s (str): a line of a Turing machine description

		Returns:

			str: a line equivalent to s but with transition label
				characters sorted

		"""
		(prefix, label) = s.split(afd.labelSeparator, 1)
	
		sortedLabel = ''.join(sorted(label))
		return prefix + afd.labelSeparator + sortedLabel

	def standardizeDescription(self, d):
		"""Return standardized version of the given Turing machine description.

		Args:

			d (str): A Turing machine description.

		Returns:

			str: a standardized version of d in which comments and
				whitespace and empty lines have been removed, the
				lines are sorted into lexicographical order, and
				labels have been sorted.

		"""
		lines = d.split('\n')
		# remove comments
		lines = afd.stripComments(lines)
		# remove all whitespace (not just leading and trailing whitespace)
		lines = [re.sub(r'\s+', '', line) for line in lines]
		# remove empty lines
		lines = [x for x in lines if x!='']
		# sort characters within each label
		lines = [self.sortLabelChars(x) for x in lines]
		# sort
		lines.sort()
		# return single string with lines separated by newlines
		return '\n'.join(lines)
	 


	def unifyTransitions(self):
		"""Unify all transitions in this machine

		Transitions with the same source and destination state can be
		unified into a single transition with a longer label. This can
		be a useful way to simplify machine descriptions and to
		standardize them.

		"""
		if self.transitions == None: return
		newTransitionsDict = dict()
		for state, tList in self.transitions.items():
			# key is tuple of all except label, value is list of labels
			tDict = dict()
			for t in tList:
				key = t.getKeyForUnify()
				labels = tDict.setdefault(key, [])
				labels.append(t.label)
			newTList = []
			for key, labels in tDict.items():
				labelStr = ''.join(labels)
				newTrans = Transition.reassembleFromUnifyKey(key, labelStr)
				newTList.append(newTrans)
			newTransitionsDict[state] = newTList
		self.transitions = newTransitionsDict

   
	""" IMPLEMENTA LAS TRANSICIONES REALIZADAS POR EL AUTÓMATA PARA COMPROBAR SI UNA PALABRA DADA input ES ACEPTADA """
  

	def run(self, input):
		"""Apply the given transition to the current configuration.

		This implements one computational step of the Turing machine,
		following the given transition to its destination state,
		writing a symbol onto the tape if necessary, and moving the
		head if necessary.

		Args:

			t (Transition): the Transition to be followed. If t is
				None and implicit rejection is permitted, the machine
				will transition into the project state.

		"""

		state = self.states[0]
		step = 0      

		"""self.printTransitions()  

		print ("TRANSITION Q0")
		print (self.getTransitions("q0"))
		"""
		if self.testEmpty() == True:
			print("Lenguaje VACIO")
			return "E"

		if self.testFinite() == False:
			print("Lenguaje INFINITO")
		else:
			print("Lenguaje FINITO")

		print("TRANSICIONES")
		self.printTransitions()

		# Comprobamos si nuestro autómata es determinista
		if self.checkDeterminist() == True:
			print("Automata DETERMINISTA: ")
			# Completamos el AFD añadiendo un estado de error para las transiciones no definidas
			self.addError()
		else:
			print("Automata NO DETERMINISTA")

		print("TRANSICIONES")
		self.printTransitions()

		for c in input:
		   if self.verbose:
				print ("Step " + str(step) + " Current state " + state)
				print ("Reading " + c)
		   trans = self.getValidTransitions(c,state)
		   if len(trans) == 0:
				if self.allowImplicitReject:
					return 'NO'
					if self.verbose:
						print ("Input Rejected, No defined transition")
				else:
					print ("Error, No defined transition")
					return "E"
		   elif len(trans) ==1 :
				t = trans[0]
				state = t.destState
				if self.verbose:
					 print  ("Moving to state " + state)
				step = step + 1

		   else:
				print  ("Error, Determinist Automata with more than a transition applicable")
				return "E"

		if state in self.final:
			if self.verbose:
					print  ("Input accepted. Final State")
					return 'SI'
		else:
				if self.verbose:
					print  ("Input rejected. Non Final State")
					return 'NO'


		


	def checkDeterminist(self):
		""" Comprueba que el autómata es realmente determinista
			Devuelve true si es determinista, false en caso contrario

			Un autómata es determinista si en cualquier estado y para cualquier símbolo del alfabeto leido, 
			existe una única transición posible
		"""
		label=[]
		destStates = []
		complete = True
		if self.transitions:
			for state in self.transitions.values():		# Agrupamos por estados
				for i in range(len(label)):				# Vaciamos lista de labels del estado anterior
					label.pop()
				for i in range(len(destStates)):		# Vaciamos lista de destStates del estado anterior
					destStates.pop()
				for transition in state:
					if transition.label in label:		# Si para ese estado destino encontramos una label repetida
						return False
					if transition.destState in destStates:	# Si repetimos una transicion a un mismo estado
						return False
					else:
						label.append(transition.label)
						destStates.append(transition.destState)
				for globLabel in self.alphabet:
					if globLabel not in label:			# Si hay un simbolo del alfabeto para el que no hay definida una transicion
						complete = False
			
			if complete == False:
				print("AFD NO COMPLETO")
			return True
		return False



	def addError(self):
		""" Completa un AFD aniadiendo un estado de error para las transiciones no definidas
			Devuelve True si todo ha ido bien, False en caso de error
		"""

		label=[]
		if self.checkDeterminist() == True:
			if self.transitions:
				for state in self.transitions.values():		# Agrupamos por estados
					for i in range(len(label)):				# Vaciamos lista de labels del estado anterior
						label.pop()
					for transition in state:			# Agrupamos por estados
						label.append(transition.label)
					for mislabel in self.alphabet:
						if mislabel not in label:
							t = Transition(state[0].sourceState, self.error, mislabel)
							print("ADDING NEW ERROR TRANSITION")
							print(t)
							self.addTransition(t)

		else:
			return False

		return True



	def testEmpty(self):
		""" Comprueba si el leguaje es vacio
			Devuelve True si lo es, False en caso contrario
		"""
		print("Alfabeto:")
		print(self.alphabet)
		if not self.alphabet:
			return True
		if not self.states:
			return True
		if len(self.transitions) == 0:
			return True
		return False


	def profundidadPrimero(self, initialState, traveledStates):
		print("SOY TRAVELED")
		print(traveledStates)
		if initialState in traveledStates:
			print("YA LLEGAMOS ANTES A ")
			print(initialState)
			return False
		print(initialState)
		traveledStates.append(initialState)
		for transicion in self.getTransitions(initialState):		# Exploramos las transiciones desde el estado actual
			if self.profundidadPrimero(transicion.destState, traveledStates) == False:
				return False

	def testFinite(self):
		""" Comprueba si el lenguaje es finito.
			Devuelve True si lo es, False en caso contrario

			Un lenguaje finito es aquel cuyo autómata asociado carece de ciclos, pues esto permitiría que el autómata
			aceptase palabras infinitas """

		if self.transitions:
			for state in self.states:									# Para cada estado, veo si puedo llegar al mismo (un ciclo)
				toVisit = []
				traveledStates = []
				toVisit.append(state)
				first = True
				print("TO EXPLORE")
				print(toVisit)
				while len(toVisit) != 0:
					actualState = toVisit.pop()
					traveledStates.append(actualState)
					print("VISITANDO: ")
					print(actualState)
					print(toVisit)
					"""if actualState == state:						
						return False"""

					for transicion in self.getTransitions(actualState):		# Exploramos las transiciones desde el estado actual
						print(transicion)
						# Para cada transicion desde ese estado
						if transicion.destState == state:				# Si volvemos al estado de inicio, hay un ciclo y por tanto no es finito
							return False
						if transicion.destState not in toVisit and transicion.destState not in traveledStates:		# Si ese estado no estaba visitado
							print("Nuevo estado ")
							print(transicion.destState)
							toVisit.append(transicion.destState)			# Tambien a la lista de los estados a visitar
					

			#Si no ha encontrado ciclos
			return True

		return False


	def toDeterminist(self):
		""" Transforma un AFND aniadiendo un estado de error para las transiciones no definidas
			Devuelve True si todo ha ido bien, False en caso de error
		"""



# see testCheckTM() in checkTuringMachine.py for more detailed tests
def main():
	for (filename, inString, solution) in [
			('aut.af', '00111', 'SI'),
			('aut.af', '00110', 'NO'),
			('autND.af', '010', 'E'),
			('autFINITEDet.af', '00', 'SI'),
			('autFINITENDet.af', '02', 'SI'),
			('autEMPTY.af', '010', 'E'),
			('autCiclo.af', '0', 'E'),
			]:
		aut = afd(rf(filename))
		val = afd.run(aut, inString)
		utils.tprint('filename:', filename, 'inString:', inString, 'result:', val)
		assert val == solution

if __name__ == "__main__":
	main()